package com.test.employee;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.junit.Test;

import com.employee.service.EmployeeService;

public class TestEmployee {

	@Test(expected=FileNotFoundException.class)
	public void fileDoesNotExist() throws IOException{
		
		EmployeeService employeeService = new EmployeeService();
		String filePath = employeeService.file.getAbsolutePath();
		BufferedReader reader = new BufferedReader(new FileReader(filePath));
		reader.close();
	}
	
	@Test()
	public void fileExist() throws IOException{
		EmployeeService employeeService = new EmployeeService();
		String filePath = employeeService.file.getAbsolutePath();
		BufferedReader reader = new BufferedReader(new FileReader(filePath));
		reader.close();
	}
}
