package com.employee.bean;
public class Country {
	
	 public enum Sex {
	      MALE, FEMALE
	  }
	 
	Sex gender;
	Double salary;
	String name;

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	public Country(String name, Sex gender, Double salary) {
		this.name= name;
		this.gender = gender;
		this.salary = salary;
	}

	public Sex getGender() {
		return gender;
	}

	public void setGender(Sex gender) {
		this.gender = gender;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}