package com.employee.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.employee.bean.Country;
import com.employee.util.CurrencyConvertor;

public class EmployeeService {
	public File file = new File("resources/config/country.csv");
	
	
	public List<Country> getCountries() {

		
		String line = "", lineSeparator = ",", currency = "", fileName = file.getAbsolutePath();
		List<Country> lstCountry = new ArrayList<>();
		try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
			while ((line = reader.readLine()) != null) {
				Double salary, dollarSalary;
				String[] row = line.split(lineSeparator);
				String countryName = row[5].replace("\"", "").isEmpty() ? row[7] : row[5];
				String gender = row[2].replace("\"", "");
				salary = Double.parseDouble(row[3].replace("\"", ""));
				currency = row[6].replace("\"", "");
				dollarSalary = new CurrencyConvertor().getCurrency(currency, salary);
				lstCountry.add(new Country(countryName,
						gender.equalsIgnoreCase("male") ? Country.Sex.MALE : Country.Sex.FEMALE, dollarSalary));
			}
		} catch (IOException e) {
			System.out.println(e);
		}

		return lstCountry;

	}

	public void writeAvgSalary(List<Country> lstCountry) {
		
		try (FileWriter csvWriter = new FileWriter(new File("resources/config/countryNew1.csv"))) {
			
			Map<String, List<Country>> totalAgeByGender = lstCountry.stream()
					.collect(Collectors.groupingBy(Country::getName));

			List<Map.Entry<String, List<Country>>> totalAgeByGenderList = new ArrayList<>(totalAgeByGender.entrySet());

			Iterator<Map.Entry<String, List<Country>>> map = totalAgeByGenderList.listIterator();

			while (map.hasNext()) {
				Map.Entry<String, List<Country>> m = map.next();
				String country = m.getKey();
				List<Country> list = m.getValue();

				Map<Country.Sex, Double> cou = list.stream().collect(
						Collectors.groupingBy(Country::getGender, Collectors.averagingDouble(Country::getSalary)));

				csvWriter.append(String.join(",", "Country", "" + "Gender", "" + "Salary"));
				csvWriter.append("\n");

				List<Map.Entry<Country.Sex, Double>> totalAgeByGender1 = new ArrayList<>(cou.entrySet());

				totalAgeByGender1.stream().forEach(e -> {
					try {
						csvWriter.append(String.join(",", country, "" + e.getKey(), "" + e.getValue()));
						csvWriter.append("\n");
					} catch (Exception e1) {
						e1.printStackTrace();
					}
					System.out.println(country + " ---> Gender: " + e.getKey() + ", Average Salary: " + e.getValue());
				});
			}
			csvWriter.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
